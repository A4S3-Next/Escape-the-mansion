/* Escaped.html -- fills in the winner's stats, and wires up the
   three ways forward: look at the final board, start a new game,
   or head back to the title screen */

(function () {
  const q = new URLSearchParams(location.search);
  const name = q.get("name") || "Someone";
  const turns = q.get("turns") || "0";
  const left = q.get("left") || "0";

  const nameEl = document.querySelector(".info > h2");
  if (nameEl) nameEl.textContent = name;

  const turnsNum = document.querySelector(".Turns h2");
  if (turnsNum) turnsNum.textContent = turns;

  const leftNum = document.querySelector(".left-inside h2");
  if (leftNum) leftNum.textContent = left;

  const buttons = document.querySelectorAll(".button button, .button Button");
  // first button: View the Board (read-only look at where everyone ended up)
  if (buttons[0]) {
    buttons[0].addEventListener("click", () => {
      location.href = "board.html?view=1";
    });
  }
  // second button: New game (same players, fresh board)
  if (buttons[1]) {
    buttons[1].addEventListener("click", () => {
      localStorage.removeItem("mansionGame");
      location.href = "board.html";
    });
  }

  // "back to home" is a plain <h2>, styled like a link
  const backHome = document.querySelector(".continue > h2");
  if (backHome) {
    backHome.addEventListener("click", () => {
      localStorage.removeItem("mansionGame");
      localStorage.removeItem("mansionPlayers");
      location.href = "index.html";
    });
  }
})();
