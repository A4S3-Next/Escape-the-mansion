/* Trap.html — reads the trap the board sent over and fills in the page */

const TRAP_FLAVOR = {
  "trapdoor": "The floor gives way beneath your feet.",
  "ghost-attack": "A cold shape rushes through you.",
  "spider-nest": "You stumble into a web thick with movement.",
  "locked-door": "The handle won't budge — something's wrong with this door.",
  "collapsing-staircase": "A step crumbles away under your weight.",
  "haunted-mirror": "Your reflection moves a second too late.",
  "bat-swarm": "A screeching cloud of wings bursts from the dark.",
  "cursed-room": "The air turns heavy and cold around you.",
  "falling-chandelier": "Glass and iron crash down from above.",
  "fake-exit": "The door swings open onto a blank wall.",
};

(function () {
  const q = new URLSearchParams(location.search);
  const name = q.get("name") || "Trap";
  const icon = q.get("icon") || "";
  const effect = q.get("effect") || "";

  const h1 = document.querySelector(".main h1");
  if (h1) h1.textContent = name;

  const img = document.querySelector(".main img");
  if (img && icon) img.src = "icons/" + icon + ".svg";

  const desc = document.querySelector(".main p.Italic");
  if (desc) desc.textContent = TRAP_FLAVOR[icon] || "";

  const effectP = document.querySelector(".main p:not(.Italic)");
  if (effectP) effectP.textContent = effect;

  const btn = document.querySelector(".main button");
  if (btn) btn.addEventListener("click", () => { location.href = "board.html"; });
})();
